import os
os.system('cls' if os.name == 'nt' else 'clear')

from pymongo import MongoClient
import dns
import ssl
import operator
from datetime import datetime

# Function to get monthly sales:
def getMonthlySales(d,p,s):
    x=orderItems.aggregate([
        # Aggregate total sales in today.month-1
        {
        "$match":
            {"shipping_limit_date": 
                {
                "$regex": d
                },
            "product_id":p,
            "seller_id":s
            }
        },
        {
        "$group":
            {"_id":"$product_id",
            "total":{"$sum":"$order_item_id"}
            }
        }
    ])
    
    for each in x:
        return each['total']

# Create a connection
cluster = MongoClient("mongodb+srv://user1:Password1@cluster0.spop0.mongodb.net/eShopping?retryWrites=true&w=majority") 

# Connect with eShopping Database
db = cluster['eShopping']

# Connect to order_items collection
orderItems = db['order_items'] 
orders = db['orders']
products = db['products']
sellers = db['sellers']
product_demand = db['product_demand']

# Get the seller with highest number of items sold

cursor = orderItems.aggregate([
# Aggregate order_item_id (no. of items in an order) for each seller
    {
    "$group":
        {"_id":"$seller_id",
        "total":{"$sum":"$order_item_id"}
        }
    },
# Sort on total items sold DESCENDING (-1)
    {
    "$sort":
        {"total":-1}
    },
# Limit to the top n rows (n=1)
    {
    "$limit": 1 
    }
])

for each in cursor:
    topSeller = each["_id"]

# print("The top seller is :", topSeller)
# The top seller is : 1f50f920176fa81dab994f9023523100

# Get all products sold by the top seller
topSellerProducts = orderItems.distinct("product_id",{"seller_id":topSeller})
# topProduct[0] = '0bcc3eeca39e1064258aa1e932269894'

# Get Product catergory name in English
productCategory = products.find({"product_id":topSellerProducts[0]},{"product_category_name_english":1,"_id":0})

for each in productCategory:
    category = each['product_category_name_english']
    
# Get current year and month
today = datetime.today()

sale =[]

# For each product, get past three month's total sale
for i in range(1,13):
    if i <10:
        date = '2018-0'+str(i)+'-01'
        ddmm = '2018-0'+str(i)
    else:
        date = '2018-'+str(i)+'-01'
        ddmm = '2018-'+str(i)
    msale = getMonthlySales(ddmm,topSellerProducts[0],topSeller)
    if msale == None:
        msale = 0
    case = {'date':date,
            'msale':msale}
    sale.append(case)

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

# Import the data
df = pd.DataFrame(sale)

# Predict using linear regression
df['date'] = pd.to_datetime(df['date'])
x = np.array(df['date']).reshape(-1,1)
y = np.array(df['msale'])
model = LinearRegression().fit(x,y)
x_arr = np.array([today.month])
x_new = np.array([today.month]).reshape((-1, 1))
y_new = model.predict(x_new)

# Get product category name in english
category = products.find({"product_id":topSellerProducts[0]},{"product_category_name_english":1,"_id":0}) 

for each in category:
    productCategory = each['product_category_name_english']

print(productCategory)

df = pd.DataFrame(y_new,x_arr)
file_header = ['month','forecasted product demand'] 

# Write demand forecast to csv 
os.chdir("C:\\Users\\hemap\\Downloads\\")
df.reset_index().to_csv("ProductDemandForecast.csv", index=False, header=file_header)

# Update collection to insert next months demand value
for each in y_new:
    pred = each

myquery = { "product_id":topSellerProducts[0]}
newvalues = { "$set": { "next_month_demand": pred} }
product_demand.update_one(myquery,newvalues)
